import { Home,Navbar} from "./components/index";

function App() {
  return <div className="font-Poppins bg-white">
    <Navbar/>
    <Home />


  </div>
  
}

export default App