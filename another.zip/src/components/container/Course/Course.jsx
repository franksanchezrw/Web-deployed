import React from 'react'

const Course = () => {
	return (
		<div className="section">
			Course
			
		</div>
	)
}

export default Course