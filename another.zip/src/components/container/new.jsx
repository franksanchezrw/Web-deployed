            {/* 3 feutures onhove section starts------------------------------------------------------------------------------*/}
            {/* <h1 className="text-4xl text-center text-black pt-24 pb-16"> */}
            {/*   Our Excellent AI Solutions for Your Business */}
            {/* </ h1>  */}
            {/* <div className="grid grid-cols-1 px-24 gap-2 sm:grid-cols-2 lg:grid-cols-3"> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering value */}
            {/*     </p> */}
            {/*   </div> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 495464 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering. */}
            {/*     </p> */}
            {/*   </div> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 sm:col-span-2 lg:col-span-1 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering value. */}
            {/*     </p> */}
            {/*   </div> */}
            {/* </div> */}
{/* 3 feutures onhove section ends------------------------------------------------------------------------------*/}
{/* 3 feutures onhove section starts------------------------------------------------------------------------------*/}

            {/* <div className="grid grid-cols-1 px-24 gap-2 sm:grid-cols-2 mt-8 mb-32 lg:grid-cols-3"> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering value */}
            {/*     </p> */}
            {/*   </div> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 495464 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering value. */}
            {/*     </p> */}
            {/*   </div> */}
            {/*   <div className="p-5 md:p-7 xl:p-10 bg-white border border-white shadow-sm rounded-lg transition hover:bg-blue-200 sm:col-span-2 lg:col-span-1 dark:bg-gray-800 dark:border-gray-800 dark:hover:border-blue-400 dark:shadow-none"> */}
            {/*     <svg */}
            {/*       className="hi-outline hi-rectangle-stack inline-block w-12 h-12 text-blue-600 mb-5 dark:text-blue-500" */}
            {/*       xmlns="http://www.w3.org/2000/svg" */}
            {/*       fill="none" */}
            {/*       viewBox="0 0 24 24" */}
            {/*       strokeWidth="1.5" */}
            {/*       stroke="currentColor" */}
            {/*       aria-hidden="true" */}
            {/*     > */}
            {/*       <path */}
            {/*         strokeLinecap="round" */}
            {/*         strokeLinejoin="round" */}
            {/*         d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122" */}
            {/*       /> */}
            {/*     </svg> */}
            {/*     <h4 className="text-lg font-bold mb-2">Applied AI</h4> */}
            {/*     <p className="leading-relaxed text-gray-600 dark:text-gray-400"> */}
            {/*       Objectives of an applied AI consulting services revolve around */}
            {/*       delivering value. */}
            {/*     </p> */}
            {/*   </div> */}
            {/* </div> */}
{/* 3 feutures onhove section ends------------------------------------------------------------------------------*/}
{/*  */}
{/*                         <div className="mx-auto  max-w-7xl pb-24 sm:pt-10 sm:px-6 sm:pb-32 lg:px-8"> */}
{/*               <div className="relative isolate overflow-hidden bg-gray-900 bg-white px-6 pt-16 shadow-2xl sm:rounded-3xl sm:px-16 md:pt-24 lg:flex lg:gap-x-20 lg:px-24 lg:pt-0"> */}
{/*  */}
{/*                 <div className="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left"> */}
{/*                   <h2 className="text-2xl text-center font-bold text-black sm:text-4xl"> */}
{/*                     Boost your productivity. */}
{/*                     <br /> */}
{/*                     Start using our app today. */}
{/*                   </h2> */}
{/*                   <p className="mt-6 text-lg leading-8 text-gray-300"> */}
{/*                     Ac euismod vel sit maecenas id pellentesque eu sed */}
{/*                     consectetur. Malesuada adipiscing sagittis vel nulla. */}
{/*                   </p> */}
{/*                   <div className="mt-10 flex items-center justify-center gap-x-6 lg:justify-start"> */}
{/*                     <a */}
{/*                       href="#" */}
{/*                       className="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white" */}
{/*                     > */}
{/*                       Get started */}
{/*                     </a> */}
{/*                     <a */}
{/*                       href="#" */}
{/*                       className="text-sm font-semibold leading-6 text-white" */}
{/*                     > */}
{/*                       Learn more <span aria-hidden="true">→</span> */}
{/*                     </a> */}
{/*                   </div> */}
{/*                 </div> */}
{/*                 <div className="relative mt-16 h-80 lg:mt-8"> */}
{/*                   <img */}
{/*                     className="absolute left-0 top-0 w-[57rem] max-w-none rounded-md bg-white/5 ring-1 ring-white/10" */}
{/*                     src={sit} */}
{/*                     alt="it" */}
{/*                     width={1824} */}
{/*                     height={1080} */}
{/*                   /> */}
{/*                 </div> */}
{/*               </div> */}
{/*             </div> */}
{/*paralax starts-----------------------------------------------------------------------------*/}
        <div class="min-h-screen flex justify-center items-center bg-sea1 bg-fixed bg-no-repeat bg-cover bg-center">
          <div className="container xl:max-w-7xl mx-auto px-4 py-16 lg:px-8 lg:py-24">
            <h1 className="text-6xl text-center text-black pb-14">
              Our Excellent AI Solutions for Your Business
            </h1>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3"></div>
          </div>
        </div>
        <div className="p-10">
          <h2 className="font-bold text-4xl">Sample Section</h2>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab numquam
            eveniet reiciendis tenetur libero dolorum, porro amet, vel, sequi
            blanditiis perferendis hic suscipit at? Modi voluptatibus repellat
            quisquam! Fuga, voluptas.
          </p>
        </div>
    
          <div className="bg-sea2 min-h-screen bg-center bg-no-repeat bg-cover bg-fixed"></div>

          <div className="bg-sea3 min-h-screen bg-fixed bg-no-repeat bg-cover"></div>
